package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
@NamedQuery(
		name="SumTotal",
		query="select r from ZonalWiseReport r where r.status=:status_id and r.zones=:zone_id"
			)
public class ZonalWiseReport {

	@Id
	@GeneratedValue
	private int id;
	
	@OneToOne
	private Zones zones;
	
	
	@ManyToOne
	private Status status;
	
	private String zoneName;
	
	private String statusName;
	private double total;
	
	public ZonalWiseReport()
	{
		
	}
	
	
	public ZonalWiseReport(int id, Zones zones, Status status, String zoneName, String statusName, double total) {
		super();
		this.id = id;
		this.zones = zones;
		this.status = status;
		this.zoneName = zoneName;
		this.statusName = statusName;
		this.total = total;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Zones getZones() {
		return zones;
	}
	public void setZones(Zones zones) {
		this.zones = zones;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public String getZoneName() {
		return zoneName;
	}
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }

	        ZonalWiseReport r=(ZonalWiseReport)obj;

	        return (r.id== this.id); 
	    }
	
}
