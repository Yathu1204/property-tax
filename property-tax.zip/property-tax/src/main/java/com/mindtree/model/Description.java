package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;



@Entity
public class Description {

	@Id
	@GeneratedValue
	private int id;
	
	private String descript;

	public Description()
	{
		
	}
	
	public Description(int id, String description) {
		super();
		this.id = id;
		this.descript = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return descript;
	}

	public void setDescription(String description) {
		this.descript = description;
	}
	
	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }

	        Description d=(Description)obj;

	        return (d.id== this.id); 
	    }
	
}
