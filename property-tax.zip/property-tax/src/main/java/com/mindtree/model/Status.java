package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Status {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String status;

	public Status()
	{
		
	}
	
	public Status(int id, String description) {
		super();
		this.id = id;
		this.status = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return status;
	}

	public void setDescription(String description) {
		this.status = description;
	}

	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }

	        Status status=(Status)obj;

	        return (status.id== this.id); 
	    }
}
