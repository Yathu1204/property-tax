package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;

@NamedNativeQuery(name = "QUERY_FOR_ZOne",
query = "SELECT * FROM Booking d WHERE d.id=:id")
@Entity
public class Zones {
	
	@Id
	@GeneratedValue
	private int id;
	
	
	private String zones;

	public Zones()
	{
		
	}
	
	public Zones(int id, String zones) {
		super();
		this.id = id;
		this.zones = zones;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getZones() {
		return zones;
	}


	public void setZones(String zones) {
		this.zones = zones;
	}
	
	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }

	        Zones zones=(Zones)obj;

	        return (zones.id== this.id); 
	    }
	

}
