package com.mindtree.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(
		name="findUav",
		query="select r from UnitAreaValue r where r.status=:status_id and r.description= :description_id and r.zone=:zone_id"
			)
public class UnitAreaValue {

	
	@Id
	@GeneratedValue
	private int id;
	
	
	@ManyToOne
	private Description description;
	
	
	@ManyToOne
	private Status status;
	
	
	@ManyToOne
	private Zones zone;
	
	
	private double uav;


	public UnitAreaValue()
	{
		
	}
	
	public UnitAreaValue(int id, Description description, Status status, Zones zone, double uav) {
		super();
		this.id = id;
		this.description = description;
		this.status = status;
		this.zone = zone;
		this.uav = uav;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Description getDescription() {
		return description;
	}


	public void setDescription(Description description) {
		this.description = description;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public Zones getZone() {
		return zone;
	}


	public void setZone(Zones zone) {
		this.zone = zone;
	}


	public double getUav() {
		return uav;
	}


	public void setUav(double uav) {
		this.uav = uav;
	}
	
	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }

	        UnitAreaValue uav=(UnitAreaValue)obj;

	        return (uav.id== this.id); 
	    }
	
}
