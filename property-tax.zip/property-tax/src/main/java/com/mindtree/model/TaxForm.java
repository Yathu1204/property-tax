package com.mindtree.model;

import java.time.Year;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Positive;

@Entity
public class TaxForm {
	
	@Id
	@GeneratedValue
	private int id;
	
	
	@PastOrPresent
	@Column(name="TaxYear")
	private Year year;
	
	
	@NotBlank(message="name not blank")
	private String name;
	
	@NotBlank(message="email not blank")
	private String email;
	
	
	@NotBlank(message="address not blank")
	private String address;
	
	@NotBlank(message="zone not blank")
	@Column(name="zones")
	private String zone;
	
	
	@NotBlank(message="desc not blank")
	private String description;
	
	@NotBlank(message="status not blank")
	private String status;
	
	@Past(message="must be past")
	private Year constructedYear;
	
	@Positive(message="area cannot be negative")
	private int area;
	
	@Positive(message="calulate the tax pls")
	private double tax;
	


	public TaxForm(int id, @PastOrPresent Year year, @NotNull(message = "name not blank") String name,
			@NotNull(message = "name not blank") String email, @NotNull(message = "name not blank") String address,
			@NotNull(message = "name not blank") String zone, @NotNull(message = "name not blank") String description,
			@NotNull(message = "name not blank") String status, @Past Year constructedYear, @NotNull int area,
			double tax) {
		super();
		this.id = id;
		this.year = year;
		this.name = name;
		this.email = email;
		this.address = address;
		this.zone = zone;
		this.description = description;
		this.status = status;
		this.constructedYear = constructedYear;
		this.area = area;
		this.tax = tax;
	}

	public TaxForm()
	{
		
	}

	public Year getYear() {
		return year;
	}
	
	


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setYear(Year year) {
		this.year = year;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getZone() {
		return zone;
	}


	public void setZone(String zone) {
		this.zone = zone;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Year getConstructedYear() {
		return constructedYear;
	}


	public void setConstructedYear(Year constructedYear) {
		this.constructedYear = constructedYear;
	}


	public int getArea() {
		return area;
	}


	public void setArea(int area) {
		this.area = area;
	}


	public double getTax() {
		return tax;
	}


	public void setTax(double tax) {
		this.tax = tax;
	}
	@Override
	public int hashCode()
	{
		return java.util.Objects.hashCode(id);
		
	}
	
	 @Override
	    public boolean equals(Object obj) 
	    { 
	    if(this == obj) 
	    {
	            return true; 
	    }
	    
	        if(obj == null || obj.getClass()!= this.getClass()) 
	        {
	            return false; 
	        }
	        TaxForm form=(TaxForm)obj;

	        return (form.id== this.id); 
	    }

	
}
