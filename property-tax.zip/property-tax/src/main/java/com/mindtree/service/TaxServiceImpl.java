package com.mindtree.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;

import com.mindtree.controller.AjaxController;
import com.mindtree.exceptions.NoDataFoundException;
import com.mindtree.model.Description;
import com.mindtree.model.Status;
import com.mindtree.model.TaxForm;
import com.mindtree.model.UnitAreaValue;
import com.mindtree.model.ZonalWiseReport;
import com.mindtree.model.Zones;
import com.mindtree.repository.DescriptionRepository;
import com.mindtree.repository.StatusRepository;
import com.mindtree.repository.TaxRepository;
import com.mindtree.repository.ZonalWiseReportRepository;
import com.mindtree.repository.ZonesRepository;
//import com.restaurentsearchservice.entity.Restaurent;

@Service
public class TaxServiceImpl implements TaxService{

	@Autowired
	private TaxRepository repo;
	
	@Autowired
	private DescriptionRepository repo1;
	
	@Autowired
	private StatusRepository repo2;
	
	@Autowired
	private ZonesRepository repo3;
	
	
	@Autowired
	private ZonalWiseReportRepository repo4;
	
	
	@Autowired
	private EntityManager en;

	Logger logger= LoggerFactory.getLogger(TaxServiceImpl.class);
	@Override
	public void save(TaxForm t)
	{
		repo.save(t);
	}
	
	@Override
	@org.springframework.transaction.annotation.Transactional(isolation = Isolation.READ_COMMITTED)
	public double getUav(Status a,Description b,Zones c)
	{
		TypedQuery<UnitAreaValue> query=en.createNamedQuery("findUav",UnitAreaValue.class);
		 query.setParameter("status_id",a);
		 query.setParameter("description_id", b);
		 query.setParameter("zone_id", c);
		 List<UnitAreaValue> list=query.getResultList();
		 return list.get(0).getUav();
		
	}
	
	@Override
	public ZonalWiseReport setImp(Status a,Zones c)
	{
		ZonalWiseReport r=repo4.findByZonesAndStatus(c, a);
		return r;
		
	}
	
	@Override
	public Status getStatusByID(int id)
	{
		return repo2.findById(id).get();
	}
	
	@Override
	public Description getdescByID(int id)
	{
		return repo1.findById(id).get();
	}
	
	@Override
	public Zones gezoneByID(int id)
	{
		return repo3.findById(id).get();
	}
	
	
	@Override
	 @org.springframework.transaction.annotation.Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)	
	public void update(int id,double tax)
	{
		ZonalWiseReport r=repo4.findById(id).get();
		r.setTotal(r.getTotal()+tax);
	}
	
	@Override
	@org.springframework.transaction.annotation.Transactional(readOnly = true)
	public List<ZonalWiseReport> getall()
	{
		List<ZonalWiseReport> r=repo4.findAll();
		try
		{
		
		if(r.size()==0)
		{
			throw new NoDataFoundException("Invalid Data");
		}
		
		}
		catch(NoDataFoundException e)
		{
			logger.error("Data is not found or "+e.getMessage());
		}
		return r;
	}
	
	
}
