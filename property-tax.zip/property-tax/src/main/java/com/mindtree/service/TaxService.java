package com.mindtree.service;

import java.util.List;

import com.mindtree.model.Description;
import com.mindtree.model.Status;
import com.mindtree.model.TaxForm;
import com.mindtree.model.ZonalWiseReport;
import com.mindtree.model.Zones;

public interface TaxService {

	public void save(TaxForm t);

	

	Zones gezoneByID(int id);

	Description getdescByID(int id);

	Status getStatusByID(int id);

	double getUav(Status a, Description b, Zones c);



	ZonalWiseReport setImp(Status a, Zones c);



	void update(int id, double tax);



	List<ZonalWiseReport> getall();

}
