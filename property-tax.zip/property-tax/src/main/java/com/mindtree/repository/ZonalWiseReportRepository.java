package com.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.model.Status;
import com.mindtree.model.ZonalWiseReport;
import com.mindtree.model.Zones;


@Repository
public interface ZonalWiseReportRepository extends JpaRepository<ZonalWiseReport,Integer>{

	public ZonalWiseReport findByZonesAndStatus(Zones zones,Status status);
}
