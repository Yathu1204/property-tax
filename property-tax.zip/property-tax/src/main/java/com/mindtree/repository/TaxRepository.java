package com.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.model.TaxForm;

@Repository
public interface TaxRepository extends JpaRepository<TaxForm,Integer>{

}
