
package com.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.model.Zones;

@Repository
public interface ZonesRepository extends JpaRepository<Zones,Integer>{

}
