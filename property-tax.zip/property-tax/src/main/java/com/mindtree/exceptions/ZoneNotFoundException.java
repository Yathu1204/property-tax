package com.mindtree.exceptions;

public class ZoneNotFoundException extends Exception{
	public ZoneNotFoundException(String msg)
	{
		super(msg);
	}

}
