package com.mindtree.exceptions;

public class DescriptionNotFoundException extends Exception{
	public DescriptionNotFoundException(String msg)
	{
		super(msg);
	}

}
