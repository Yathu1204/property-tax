package com.mindtree.exceptions;

public class InvalidDateRangeException extends Exception{
	
	public InvalidDateRangeException(String msg)
	{
		super(msg);
	}

}
