package com.mindtree.exceptions;

public class StatusNotFoundException extends Exception{
	public StatusNotFoundException(String msg)
	{
		super(msg);
	}

}
