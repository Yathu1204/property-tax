package com.mindtree.exceptions;


import java.time.format.DateTimeParseException;

public class InvalidDateException extends DateTimeParseException{
	
	public InvalidDateException(String msg,String msg1,int errorIndex)
	{
		super(msg, msg1, errorIndex);
	}

}
