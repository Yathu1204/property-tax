package com.mindtree.exceptions;

public class NoDataFoundException extends Exception{
	
	public NoDataFoundException(String msg)
	{
		super(msg);
	}

}
