package com.mindtree.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.model.TaxForm;
import com.mindtree.model.ZonalWiseReport;
import com.mindtree.service.TaxService;

@Controller
public class TaxController {
	
	@Autowired
	private TaxService service;

    Logger logger= LoggerFactory.getLogger(TaxController.class);

	@GetMapping("/login")
	public String login()
	{
		return "welcome";
	}
	
	@GetMapping("/taxing")
	public String taxforming(Model m)
	{
		m.addAttribute("taxForm",new TaxForm());
		return "TaxForm";
	}
	
	
	@RequestMapping("/savetax")
	public String taxed(@Valid @ModelAttribute("taxForm")TaxForm t,BindingResult br)
	{
		if(br.hasErrors())
		{
			logger.error("Form is not filled correctly please ensure with validator conditions");
			return "TaxForm";
		}
		else
		{
			service.save(t);
			return "welcome";
			
		}
	}
	
	@GetMapping("/reports")
	public String reports(ModelMap m)
	{
		List<ZonalWiseReport> k=service.getall();
		m.put("all",k);
		return "zonalreport";
	}
}
