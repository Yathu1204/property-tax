


insert into description(id,descript)
values(1,'RCC Buildings');

insert into description(id,descript)
values(2,'RCC Cement Buildings');

insert into description(id,descript)
values(3,'Tiled/Sheet kind Builds');



insert into status(id,status)
values(1,'Owner');

insert into status(id,status)
values(2,'Tentated');


insert into zones(id,zones)
values(1,'Zone A');

insert into zones(id,zones)
values(2,'Zone B');
insert into zones(id,zones)
values(3,'Zone C');


insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(1,1,1,1,2.50);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(2,1,2,1,5.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(3,1,1,2,2.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(4,1,2,2,4.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(5,1,1,3,1.80);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(6,1,2,3,3.60);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(7,2,1,1,1.80);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(8,2,2,1,4.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(9,2,1,2,1.60);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(10,2,2,2,3.50);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(11,2,1,3,1.20);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(12,2,2,3,3.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(13,3,1,1,1.25);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(14,3,2,1,3.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(15,3,1,2,1.00);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(16,3,2,2,2.50);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(17,3,1,3,0.75);

insert into Unit_area_value(id,description_id,status_id,zone_id,uav)
values(18,1,2,3,2.00);

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(1,1,1,0,'ZONE A','OWNER');

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(2,1,2,0,'ZONE A','TENTATED');

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(3,2,1,0,'ZONE B','OWNER');

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(4,2,2,0,'ZONE B','TENTATED');

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(5,3,1,0,'ZONE C','OWNER');

insert into zonal_wise_report(id,zones_id,status_id,total,zone_name,status_name)
values(6,3,2,0,'ZONE c','TENTATED');