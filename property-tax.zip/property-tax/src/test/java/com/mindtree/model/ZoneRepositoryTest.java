package com.mindtree.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;


import com.mindtree.repository.UnitValueRepository;
import com.mindtree.repository.ZonesRepository;

@DataJpaTest
public class ZoneRepositoryTest {
	
	@Autowired
	private ZonesRepository repository;
	
	@Test
	public void testFindAll() {
		List<Zones> items = repository.findAll();
		assertEquals(3,items.size());
	}

	@Test
	public void testFindOne() {
		Zones item = repository.findById(1).get();
		
		assertEquals("Zone A",item.getZones());
	}

}