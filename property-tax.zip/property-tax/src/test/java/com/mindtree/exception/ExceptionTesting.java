package com.mindtree.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.validation.BindingResult;

import com.mindtree.controller.AjaxController;
import com.mindtree.controller.TaxController;
import com.mindtree.exceptions.InvalidDateException;
import com.mindtree.exceptions.StatusNotFoundException;
import com.mindtree.exceptions.ZoneNotFoundException;
import com.mindtree.model.Description;
import com.mindtree.model.Status;
import com.mindtree.model.TaxForm;
import com.mindtree.model.Zones;
import com.mindtree.service.TaxService;

@SpringBootTest
class ExceptionTesting {

	
	@Autowired
	private TaxService service;
	
	
	@Autowired
	private TaxController controller;

	
	private BindingResult br;
	
	private TaxForm testingForm;
	private Status status;
	private Description desc;
	private Zones zone;
	
	
	@BeforeEach
	void setup()
	{
		testingForm=new TaxForm();
		testingForm.setId(1);
		testingForm.setName("saii");
		testingForm.setAddress("hyderabad");
		testingForm.setArea(1200);
		testingForm.setStatus("1");
		testingForm.setZone("1");
		testingForm.setDescription("1");
		 status=service.getStatusByID(1);
		 desc=service.getdescByID(1);
		 zone=service.gezoneByID(1);
		
	}
	
	@Test
		void exceptionTesting() {
		    
		    Throwable exception = assertThrows(ZoneNotFoundException.class, () -> testingForm.setZone("4"));
		    assertEquals("No zone Found", exception.getMessage());
		}
		
		
		@Test
		void exceptionTesting1() {
		    
		    Throwable exception = assertThrows(StatusNotFoundException.class, () -> testingForm.setStatus("4"));
		    assertEquals("No Status Found", exception.getMessage());
		}

		@Test
		void exceptionTesting2() {
		    
		    Throwable exception = assertThrows(StatusNotFoundException.class, () -> testingForm.setDescription("4"));
		    assertEquals("No Description Found", exception.getMessage());
		}
	
}

