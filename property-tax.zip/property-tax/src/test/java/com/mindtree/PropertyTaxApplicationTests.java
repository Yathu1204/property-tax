package com.mindtree;

import java.time.Year;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.validation.BindingResult;

import com.mindtree.controller.AjaxController;
import com.mindtree.controller.TaxController;
import com.mindtree.exceptions.InvalidDateException;
import com.mindtree.exceptions.StatusNotFoundException;
import com.mindtree.exceptions.ZoneNotFoundException;
import com.mindtree.model.Description;
import com.mindtree.model.Status;
import com.mindtree.model.TaxForm;
import com.mindtree.model.Zones;
import com.mindtree.service.TaxService;

@SpringBootTest
class PropertyTaxApplicationTests {

	
	@Autowired
	private TaxService service;
	
	
	@Autowired
	private TaxController controller;

	
	private BindingResult br;
	
	private TaxForm testingForm;
	private Status status;
	private Description desc;
	private Zones zone;
	
	
	@BeforeEach
	void setup()
	{
		testingForm=new TaxForm();
		testingForm.setId(1);
		testingForm.setName("saii");
		testingForm.setAddress("hyderabad");
		testingForm.setArea(1200);
		testingForm.setStatus("1");
		testingForm.setZone("1");
		testingForm.setDescription("1");
		 status=service.getStatusByID(1);
		 desc=service.getdescByID(1);
		 zone=service.gezoneByID(1);
		
	}
	
	
	@Test
	void uavCalculation()
	{
		double d=service.getUav(status,desc,zone);
		assertEquals(2.50,d);
	}
	
	
	@Test
	void errorform()
	{
		String s=controller.taxed(testingForm, br);
		assertEquals("taxform",s);
	}
	
	
	
	
}
